SWING THE CAT
By Patrick Woodcock (Patbert)
www.patbert.co.uk

YOUR MISSION:
Collect all the cat food in the level.  

CONTROLS:
Press space to dig in claws, press space again to retract claws.

CAST:
Cattius McCat: You, the heroic cat
Sir Swings Alot Acats: Your evil owner who is a knight, use him to protect you from mines and other enemies.

This game is an entry for the One Week One Button 2 contest. (http://www.rav.efbnet.com/1w1b2/)

Game developed in RealBasic, images created in MS Paint and GIMP, soundtrack is a mixture of Bach, Beethoven and some other stuff (public domain midi from http://www.mutopiaproject.org/).  Special thanks to Hannah for drawing the dog.

This program's unmodified zip file may be freely distributed.

20/Nov/05